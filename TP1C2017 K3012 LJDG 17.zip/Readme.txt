﻿
● Curso: K3012

● Número de grupo: 17

● Nombre y legajo de todos los integrantes:

RODRIGUEZ, Luis		149567-7
BULBULIAN, Juan Pablo	116134-9
COHEN, Damián		143668-5
BROWARNIK, Gabriel	151893-8

● Email del integrante responsable del grupo:

joserpg94@gmail.com


